export class Lobby {}
