export class CreateAuthenticationDto {}
