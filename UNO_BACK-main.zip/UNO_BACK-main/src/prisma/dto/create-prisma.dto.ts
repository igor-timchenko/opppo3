export class CreatePrismaDto {}
